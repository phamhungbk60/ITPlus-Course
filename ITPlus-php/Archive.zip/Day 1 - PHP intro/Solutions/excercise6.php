<?php

$date = 2;

switch ($date) {
    case 0: 
        echo "Ngày thứ 2";
        break;
    case 1:
        echo "Ngày thứ 3";
        break;
    case 2:
        echo "Ngày thứ 4";
        break;
    case 3:
        echo "Ngày thứ 5";
        break;
    case 4:
        echo "Ngày thứ 6";
        break;
    case 5:
        echo "Ngày thứ 7";
        break;
    case 6:
        echo "Ngày chủ nhật";
        break;
    default:
        echo "Không hợp lệ";
}