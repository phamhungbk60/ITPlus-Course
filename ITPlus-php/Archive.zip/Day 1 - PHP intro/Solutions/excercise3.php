<?php

$firstInput = 1;
$secondInput = 2;

echo $firstInput + $secondInput . '<br/>';
echo $firstInput - $secondInput . '<br/>';
echo $firstInput * $secondInput . '<br/>';
echo $firstInput / $secondInput . '<br/>';
echo $firstInput % $secondInput . '<br/>';