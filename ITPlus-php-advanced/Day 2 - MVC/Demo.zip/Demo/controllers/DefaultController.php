<?php 

class DefaultController 
{
    public function index()
    {
        echo "This is default controller";
    }
}