<?php 

// for ($i = 1; $i <= 50; $i++) {
//     echo "<p>{$i}</p>";
// }

$i = 1;

while ($i <= 50) {
    echo "<p>{$i}</p>";
    $i++;
}