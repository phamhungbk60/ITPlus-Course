<?php 

$a = 3;

if ($a % 2 == 0) {
    echo "$a là số chẵn";
} else {
    echo "$a là số lẻ";
}