<?php
$a = 2;
$b = 2;

if ($a === $c) {
    echo ($a + $b) * 3;
} else {
    echo $a + $b;
}